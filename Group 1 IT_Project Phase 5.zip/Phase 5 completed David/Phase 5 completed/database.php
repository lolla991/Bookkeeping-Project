<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Uni_Design_ITPROJECT.css">
    <link rel="stylesheet" href="style.css">

    <style>
        body {
            flex-direction: row;
            padding-right: 30px;
            height: 100vh;
        }
        .login-box {
            margin-left: 30px;
            max-width: 500px;
            max-height: 500px;
            height: 500px;
            width: 400px;
        }
        input[type="email"],
        input[type="password"],
        input[type="text"] { /* Added a comma here */
            width: 100%;
            padding: 12px;
            font-size: 14px;
            background-color: #f1f8e9;
            color: #05445e;
            border: 1px solid #c8e6c9; 
            border-radius: 5px;
            margin-top: 5px;
            outline: none; /* Ensure outline is none */
        }

        input[type="email"]:focus,
        input[type="password"]:focus,
        input[type="text"]:focus { /* Added a comma here */
            border-color: #75e6da; 
            outline: none; 
        }
        .data-box {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
            margin-left: 30px;
            max-width: 500px;
            max-height: 900px;
            height: 500px;
            width: 900px;
        }
    </style>
    <title>Database</title>
    <script src="https://kit.fontawesome.com/a05a62846d.js" crossorigin="anonymous"></script>
</head>

<body>
<?php
    include('Registerdatabase.php');

    // Check connection
    // if ($conn->connect_error) {
    //     die("Connection failed: " . $conn->connect_error);
    // }

    // Initialize variables for input values
    $item = $registered_code = $total = '';
    $records = [];

    
    if (isset($_POST['item'])) {
        $item = $_POST['item'];
        $registered_code = $_POST['registered_code'];
        $total = $_POST['total'];

       
        $stmt = $conn->prepare("INSERT INTO records (items, registered_code, total) VALUES (?, ?, ?)");
        if (!$stmt) {
            die("Preparation failed: " . $conn->error);
        }
        $stmt->bind_param("ssd", $item, $registered_code, $total);

        
        if ($stmt->execute()) {
            echo "<script>alert('Record added successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    }

    
    $result = $conn->query("SELECT * FROM records");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $records[] = $row;
        }
    }



   
    $conn->close();
?>

    <div class="nav">
        <header>Book-Keeping</header>
        <ul>
            <li><a href="About_Page.php" aria-label="About Page"><i class="fas fa-qrcode"></i> About</a></li>
            <li><a href="application.php" aria-label="Database"><i class="fas fa-database"></i> Database</a></li>
            <li><a href="ReportPage.php" aria-label="Report Page"><i class="fas fa-file"></i> Report</a></li>
            <li><a href="HomePage.php" aria-label="Logout"><i class="fas fa-arrow-circle-left"></i> Logout</a></li>
        </ul>
    </div>

    <div class="login-container">
        <div class="login-box">
            <form method="POST" action="">
                <div class="input-group">
                    <label for="item">Item</label>
                    <input type="text" id="item" name="item" placeholder="Purchased Item" value="<?php echo htmlspecialchars($item); ?>" required>
                </div>

                <div class="input-group">
                    <label for="registered_code">Registered Code</label>
                    <input type="text" id="registered_code" name="registered_code" placeholder="Registered Code" value="<?php echo htmlspecialchars($registered_code); ?>" required>
                </div>

                <div class="input-group">
                    <label for="total">Total</label>
                    <input type="text" id="total" name="total" placeholder="Total" value="<?php echo htmlspecialchars($total); ?>" required>
                </div>

                <div class="enter-button">
                    <button type="submit">Enter</button><br>
                </div>
                <br>
                <div class="clear-button">
                    <button type="reset">Clear</button><br>
                </div>
            </form>
        </div>
    </div>

    <div class="data-box">
        <h2>Record</h2>
        <div class="table">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Item</th>
                    <th>Registered Code</th>
                    <th>Total</th>
                </tr>
                <?php foreach ($records as $record): ?>
                <tr>
                    <td><?php echo isset($record['id']) ? $record['id'] : 'N/A'; ?></td>
                    <td><?php echo isset($record['item']) ? htmlspecialchars($record['item']) : 'N/A'; ?></td>
                    <td><?php echo isset($record['registered_code']) ? htmlspecialchars($record['registered_code']) : 'N/A'; ?></td>
                    <td><?php echo isset($record['total']) ? htmlspecialchars($record['total']) : 'N/A'; ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body>
</html>
