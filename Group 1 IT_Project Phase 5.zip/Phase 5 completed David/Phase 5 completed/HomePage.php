<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | BookKeeping Sytem</title>

    <style>
        body{
            float:none;
            max-height: fit-content;
            height: auto;
        }

        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap');
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins',sans-serif;
        }

        body{
            display: flex;
            justify-content: center;
            align-items: center;
            height:100vh;
            margin-right: 0px;
            margin-left: 90px;
            padding-right: 15px;
            background-image: linear-gradient(to top right, #d4f1f4 , #75e6da ,  #05445e);
        }
        .login-box{
            display: flex;
            justify-content: center;
            flex-direction: column;
            width: auto;
            height: auto;
            padding: 30px;
            transition: all .5s;
        }
        .login-header{
            color: #05445e;
            text-align: center;
            margin: 20px 0 40px 0;
        }

        .login-header header
        {
            color: #05445e;
            font-weight: bold;
            font-size: 20px;
        }

        .input-box .input-field{
            width: 100%;
            height: 60px;
            font-size: 17px;
            padding: 0 25px;
            margin-bottom: 15px;
            border-radius: 30px;
            border: none;
            box-shadow: 0px 5px 10px 1px rgba(0,0,0, 0.05);
            outline: none;
            transition: .3s;
        }
        ::placeholder{
            font-weight: 500;
            color: #222;
        }
        .input-field:focus{
            width: 105%;
        }
        .forgot{
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }
        section{
            display: flex;
            align-items: center;
            font-size: 14px;
            color: #555;
        }
        #check{
            margin-right: 10px;
        }
        a{
            text-decoration: none;
        }
        a:hover{
            text-decoration: underline;
        }
        section a{
            color: #555;
            font-weight: bold;
        }
        .input-submit{
            position: relative;
        }
        .submit{
            width: 100%;
            height: 60px;
            background: #05445e;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: .3s;
        }
        .input-submit label{
            position: absolute;
            top: 45%;
            left: 50%;
            color: #fff;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            cursor: pointer;
        }
        .submit:hover{
            background: #000;
            transform: scale(1.05,1);
        }
        .sign-up-link{
            text-align: center;
            font-size: 15px;
            margin-top: 20px;
        }
        .sign-up-link a{
            color: #000;
            font-weight: 600;
        }
        .bookkeeping_image {
            display: flex;
            justify-content: center; /* Center horizontally */
            margin-bottom: 20px; /* Space below the image */
        }

        .footer{
            justify-content: center;
            text-align: center;
            font-size: 15px;
        }
        .title{
            margin-top: 20px;
            justify-content: center;
        }
        .nav{
            position: fixed;
            padding: 20px;
            color: #004d40;
            border-radius: 0px;
            left:0px;
            width: 250px;
            height:100%;
            background: #05445e;
            /*transition: all .5s ease;*/
        }
        .nav header{
            font-size: 22px;
            text-align: center;
            line-height: 70px;
            user-select: none;
            color: white;
        }
        .nav ul a{
            display: block;
            height: 100%;
            width:100%;
            line-height: 65px;
            font-size: 15px;
            padding-left: 20px;
            box-sizing: border-box;
            border-top: 1px solid rgba(255, 255, 255, .1);
            transition: .4s;
        }
        ul li:hover a{
            padding-left: 50px;
        }
        .nav ul a i{
            margin-right: 16px;
            color: white;
        }
    </style>
    <!--<script defer src="./IT_Project_Script.js"></script>-->
</head>
<body>
<?php 
include('Registerdatabase.php'); 


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    
    $checkQuery = $conn->prepare("SELECT reg_password FROM registration WHERE reg_email = ?");
    $checkQuery ->bind_param("s", $email);
    $checkQuery ->execute();
    $checkQuery ->store_result();
    
    if ($checkQuery ->num_rows > 0) {
        $checkQuery ->bind_result($hashed_password);
        $checkQuery ->fetch();

        if (password_verify($password, $hashed_password)) {
            echo "<script>alert('Login successful!'); window.location.href='Welcome_Page.php';</script>";
        } else {
            echo "<script>alert('Invalid password. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('No user found with this email.');</script>";
    }

    $checkQuery ->close();
    $conn->close();
}
?>

   <div class="login-box">
       <div class="title">
           <h2>Book-Keeping System</h2>
       </div>
       <div class="bookkeeping_image">
           <img src="lg.jpeg" width="140" height="140" alt="Logo">
       </div>
       <div class="login-header">
           <header>Login</header>
       </div>
       <form id="form" action="Welcome_Page.php" method="POST">
           <div class="input-box">
               <input type="text" class="input-field" name="email" id="email" placeholder="Email" required>
           </div>
           <div class="input-box">
               <input type="password" class="input-field" name="password" id="password" placeholder="Password" required>
           </div>
           <div class="forgot">
               <section>
                   <input type="checkbox" id="check">
                   <label for="check">Remember me</label>
               </section>
               <section>
                   <!--<a href="#">Forgot password</a>-->
               </section>
           </div>
           <div class="input-submit">
               <button type="submit" class="submit" id="submit">Sign In</button>
           </div>
           <div class="sign-up-link">
               <p>Don't have an account? <a href="Registration_Page.php">Sign Up</a></p>
           </div>
       </form>
       <div class="footer">
           <footer>
               <b>IT Project: Book-Keeping System<br>Members: Cana | Lisa | Aammarah | Lolla | Erick</b>
           </footer>
       </div>        
   </div>
   <script>
    const form = document.getElementById('form');
    form.addEventListener('submit', e => {
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();

        if (email === '' || password === '') {
            e.preventDefault();
            alert('Please fill in all fields.');
        }
    });
</script>

</body>
</html>