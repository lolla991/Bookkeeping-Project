<?php 
include('Registerdatabase.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $first = $conn->real_escape_string($_POST['firstname']);
    $last = $conn->real_escape_string($_POST['lastname']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);
    $confirmPassword = $_POST['confirmPassword'];

    if ($password !== $confirmPassword) {
        echo "Passwords do not match.";
        exit();
    }
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $query = "INSERT INTO registration (reg_firstname, reg_lastname, reg_email, reg_password) 
              VALUES ('$first', '$last', '$email', '$hashedPassword')";

    if ($conn->query($query) === TRUE) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Register</title>
    <style>
         @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap');
         @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap');
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        body {
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: linear-gradient(to top right, #d4f1f4, #75e6da, #189ab4, #05445e);
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .login-box {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%; /* Set width to 100% to allow flexbox centering */
            display: flex;
            flex-direction: column;
            align-items: center; /* Center contents inside the box */
            transition: all 0.5s;
        }


        h2 {
            font-weight: 500;
            color: #004d40; 
            margin-bottom: 20px;
            text-align: center;
        }


        .input-group {/
            margin-bottom: 20px;
        }

        label {
            font-size: 14px;
            color: #05445e; 
        }

        input[type="email"],
        input[type="password"],
        input[type="text"] { /* Added a comma here */
            width: 100%;
            padding: 12px;
            font-size: 14px;
            background-color: #f1f8e9;
            color: #05445e;
            border: 1px solid #c8e6c9; 
            border-radius: 5px;
            margin-top: 5px;
            outline: none; /* Ensure outline is none */
        }

        input[type="email"]:focus,
        input[type="password"]:focus,
        input[type="text"]:focus { /* Added a comma here */
            border-color: #75e6da; 
            outline: none; 
        }
        .login-header{
            color: #05445e;
            text-align: center;
            margin: 20px 0 40px 0;
        }

        .login-header header
        {
            color: #05445e;
            font-weight: bold;
            font-size: 20px;
        }

        .input-box .input-field{
            width: 100%;
            height: 60px;
            font-size: 17px;
            padding: 0 25px;
            margin-bottom: 15px;
            border-radius: 30px;
            border: none;
            box-shadow: 0px 5px 10px 1px rgba(0,0,0, 0.05);
            outline: none;
            transition: .3s;
        }
        ::placeholder{
            font-weight: 500;
            color: #222;
        }
        .input-field:focus{
            width: 105%;
        }
        .forgot{
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #05445e; 
            color: #ffffff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            transition: .3s;
        }
        section{
            display: flex;
            align-items: center;
            font-size: 14px;
            color: #555;
        }
        #check{
            margin-right: 10px;
        }
        a{
            text-decoration: none;
        }
        a:hover{
            text-decoration: underline;
        }
        section a{
            color: #555;
            font-weight: bold;
        }
        .input-submit{
            position: relative;
        }
        .submit{
            width: 100%;
            height: 60px;
            background: #05445e;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: .3s;
        }
        .input-submit label{
            position: absolute;
            top: 45%;
            left: 50%;
            color: #fff;
            -webkit-transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            cursor: pointer;
        }
        .submit:hover{
            background: #000;
            transform: scale(1.05,1);
        }
        .sign-up-link{
            text-align: center;
            font-size: 15px;
            margin-top: 20px;
        }
        .sign-up-link a{
            color: #000;
            font-weight: 600;
        }
        .bookkeping_image img{
            justify-content: center;    
        }
        .footer
        {
            justify-content: center;
            text-align: center;
            font-size: 15px;
        }

        button:hover {
            background-color: #189ab4;
        }

        button:active {
            background-color: #05445e; 
        }

        .nav{
            position: fixed;
            padding: 20px;
            color: #004d40;
            border-radius: 0px;
            left:0px;
            width: 250px;
            height:100%;
            background: #05445e;
            /*transition: all .5s ease;*/
        }
        .nav header{
            font-size: 22px;
            text-align: center;
            line-height: 70px;
            user-select: none;
            color: white;
        }
        .nav ul a{
            display: block;
            height: 100%;
            width:100%;
            line-height: 65px;
            font-size: 15px;
            padding-left: 20px;
            box-sizing: border-box;
            border-top: 1px solid rgba(255, 255, 255, .1);
            transition: .4s;
        }
        ul li:hover a{
            padding-left: 50px;
        }
        .nav ul a i{
            margin-right: 16px;
            color: white;
        }

        .error-message {
            color: #e57373;
            text-align: center;
            margin-top: 10px;
        }


        p {
            text-align: center;
            color: #05445e;;
        }

        a {
            color: #189ab4; 
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }


        @media (max-width: 600px) {
            .login-box {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Create a new account</h2>
            <form id="form" action="Registration_Page.php" method="POST">
                <div class="input-group">
                    <label for="firstname">First Name</label>
                    <input type="text" id="firstname" name="firstname" placeholder="Enter your First Name">
                    <div class="error"></div>
                </div>
                <div class="input-group">
                    <label for="lastname">Last Name</label>
                    <input type="text" id="lastname" name="lastname" placeholder="Enter your Last Name">
                    <div class="error"></div>
                </div>
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email">
                    <div class="error"></div>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Create a password">
                    <div class="error"></div>
                </div>
                <div class="input-group">
                    <label for="confirmPassword">Confirm Password</label>
                    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password">
                    <div class="error"></div>
                </div>
                <div class="input-group">
                    <button type="submit" id="submit" name="submit">Register</button>
                </div>
                <p>Already have an account? <a href="HomePage.php">Login</a></p>
            </form>
        </div>
    </div>
    <script>
    const form = document.getElementById('form');
    const firstname = document.getElementsByName('firstname')[0];
    const lastname = document.getElementsByName('lastname')[0];
    const email = document.getElementsByName('email')[0];
    const password = document.getElementsByName('password')[0];
    const confirmPassword = document.getElementsByName('confirmPassword')[0];

    form.addEventListener('submit', e => {
        // Check if all inputs are valid before allowing the form to submit
        if (!validateInputs()) {
            e.preventDefault();  // Prevent form submission if validation fails
        }
    });

    const setError = (element, message) => {
        const inputControl = element.parentElement;
        const errorDisplay = inputControl.querySelector('.error');
        errorDisplay.innerText = message;
        inputControl.classList.add('error');
        inputControl.classList.remove('success');
    };

    const setSuccess = element => {
        const inputControl = element.parentElement;
        const errorDisplay = inputControl.querySelector('.error');
        errorDisplay.innerText = '';
        inputControl.classList.add('success');
        inputControl.classList.remove('error');
    };

    const isValidEmail = email => {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    };

    const validateInputs = () => {
        const firstnameValue = firstname.value.trim();
        const lastnameValue = lastname.value.trim();
        const emailValue = email.value.trim();
        const passwordValue = password.value.trim();
        const confirmPasswordValue = confirmPassword.value.trim();

        let isValid = true;

        if (firstnameValue === '') {
            setError(firstname, 'First name is required');
            isValid = false;
        } else {
            setSuccess(firstname);
        }

        if (lastnameValue === '') {
            setError(lastname, 'Last name is required');
            isValid = false;
        } else {
            setSuccess(lastname);
        }

        if (emailValue === '') {
            setError(email, 'Email is required');
            isValid = false;
        } else if (!isValidEmail(emailValue)) {
            setError(email, 'Provide a valid email address');
            isValid = false;
        } else {
            setSuccess(email);
        }

        if (passwordValue === '') {
            setError(password, 'Password is required');
            isValid = false;
        } else {
            setSuccess(password);
        }

        if (confirmPasswordValue === '') {
            setError(confirmPassword, 'Please confirm your password');
            isValid = false;
        } else if (passwordValue !== confirmPasswordValue) {
            setError(confirmPassword, 'Passwords do not match');
            isValid = false;
        } else {
            setSuccess(confirmPassword);
        }

        return isValid; // Return true if all fields are valid
    };
</script>

</body>
</html>

