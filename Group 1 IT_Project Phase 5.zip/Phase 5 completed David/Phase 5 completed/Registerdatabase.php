<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "database"; // Database may have to change

try{
    $conn = mysqli_connect($servername, $username, $password, $dbname);
}
catch(mysqli_sql_exception){
    echo'<script>alert("You are not connected")</script>';
}

 if($conn)
 {
     echo '<script>alert("You are connected to the database.")</script>';
 }
?>

