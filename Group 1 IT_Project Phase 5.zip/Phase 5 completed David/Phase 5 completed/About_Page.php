<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Uni_Design_ITPROJECT.css">
    <link rel="stylesheet" href="style.css">

    <title>About | BookKeeping System</title>
    <script src="https://kit.fontawesome.com/a05a62846d.js" crossorigin="anonymous"></script>

	<style type="text/css">
        .login-box {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin-right: 65px;
            width: 100%;
        }
        body
        {
            flex-direction:column;
            padding-right: 30px;
        }
	</style>
</head>
<body>
    <div class="nav">
        <header>Book-Keeping</header>
        <ul>
        <li><a href="About_Page.php" ><i class="fas fa-qrcode"></i> About</a></li>
            <li><a href="applications.php"><i class="fas fa-database"></i> Database</a></li>
            <li><a href="ReportPage.php"><i class="fas fa-file"></i> Report</a></li>
            <li><a href="HomePage.php"><i class="fas fa-arrow-circle-left"></i> Logout</a></li>
        </ul>
    </div>
    <br>
    <br>
        <div class="login-box" >
            <h1>About Book-Keeping System</h1>
            <p>This Book-Keeping System is designed to help small businesses manage their finances efficiently.
			It provides tools for tracking income, expenses, and generating financial reports. 
			By using this system, businesses can ensure accurate financial records, make informed decisions, and improve overall productivity.</p>
            <p><b>Key Benefits:</b></p>
            <ul>
                <li>Easy tracking of income and expenses</li>
                <li>Provision of Financial Reports</li>
                <li>Improved Financial accuracy</li>
                <li>Better Decision-making</li>
                <li>Increased Productivity</li>
            </ul>
            <br><br>
            <div class="footer">
                <footer>
                    <b>
                        IT Project: Book-Keeping System<br>
                        Members:  Ammaarah | Cana | Erick | Jason | Lisa | Lolla
                    </b>
                </footer>
          </div>
        </div><br>
<br>

<!--<script>
       function toggleSidebar() {
            var sidebar = document.getElementById("sidebar");
            var hamburger = document.getElementById("hamburger");
            if (sidebar.style.width === "250px") {
                sidebar.style.width = "0";
                hamburger.style.zIndex = "1"; // Brings the hamburger icon back to the front
            } else {
                sidebar.style.width = "250px";
                hamburger.style.zIndex = "-1"; // Hides hamburger icon behind the sidebar
            }
        }

       function logout() {
            alert("You have been logged out!");
        }
</script>-->
</body>
</html>
