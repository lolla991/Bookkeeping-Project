<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Small Business Bookkeeping App</title>
    <style>
        /* CSS styles */
        body {
            font-family: 'Roboto', sans-serif;
            align-items: center;
            padding: 20px;
            background-image: linear-gradient(to top right, #d4f1f4 , #75e6da , #189ab4, #05445e); /* Light aqua background */
            color: #004d40; 
            display: flex;
            justify-content: center;
            display: flex;
            flex-direction:column; 
            height: 100vh; 
            margin: 0; 
        }
        header {
            text-align: center;
            margin: 0; 
            padding: 20px 0; 
            width: 100%; 
            position: relative; 
            z-index: 1;
        }
        .nav{
            position: fixed;
            padding: 20px;
            color: #004d40;
            border-radius: 0px;
            background: #05445e;
            /*transition: all .5s ease;*/
            top: 0; 
            left: 0;
            width: 250px;
            height: 100vh; 
            position: fixed; 
            z-index: 2; /* Ensure nav is above the header */

        }
        .nav header{
            font-size: 22px;
            text-align: center;
            line-height: 70px;
            user-select: none;
            color: white;
        }
        .nav ul a{
            display: block;
            height: 100%;
            width:100%;
            line-height: 65px;
            font-size: 15px;
            padding-left: 20px;
            box-sizing: border-box;
            border-top: 1px solid rgba(255, 255, 255, .1);
            transition: .4s;
        }
        ul li:hover a{
            padding-left: 50px;
        }
        .nav ul a i{
            margin-right: 16px;
            color: white;
        }
        a {
            color: #189ab4; 
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
        section {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
            width: 100%;
            max-width: 600px;
            float:right;
        }
        h2, h1 {
            margin-top: 0;
            color:black;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input, textarea, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .cash-flow-container {
            display: flex;
            float: right;
            background-color: #ffffff;
            padding: 30px;
            gap: 30px;
            width: 80%;
        }
        .cash-flow-section {
            border: 3px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            flex: 1;
        }
        .main-form{
            background-color: #ffffff;
            padding: 30px;
            border: 3px solid #ccc;
        }
        main {
            margin-left: 250px; 
            display: flex;
            justify-content: center; 
            align-items: center;
            height: 100%; 
            padding-top: 20px;
        }
        .list {
            margin-top: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            max-height: 200px;
            overflow-y: auto;
        }
        table {
            width: 100%;
            margin-top: 10px;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .bookingform_container {
            width: 100%; /* Make it responsive */
            max-width: 600px; /* Keep a max width for the form */
        }
    </style>
</head>
<body>

<?php
include("Registerdatabase.php");
// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Insert business information
    if (isset($_POST['submit'])) {
        $businessName = $_POST['business-name'];
        $businessAddress = $_POST['business-address'];
        $taxId = $_POST['tax-id'];

        $query = "INSERT INTO users (business_name, business_address, tax_id) 
        VALUES ('$businessName', '$businessAddress', '$taxId')";
        mysqli_query($conn, $query);
    }
}
mysqli_close($conn);

?>

<header>
        <h1>Small Business Bookkeeping App</h1>
    </header>
    <div class="nav">
        <header>Book-Keeping</header>
        <ul>
            <li><a href="About_Page.php" aria-label="About Page"><i class="fas fa-qrcode"></i> About</a></li>
            <li><a href="applications.php" aria-label="Database"><i class="fas fa-database"></i>Business Info</a></li>
            <li><a href="ReportPage.php" aria-label="Report Page"><i class="fas fa-file"></i> Cash Inflow/ Outflow</a></li>
            <li><a href="HomePage.php" aria-label="Logout"><i class="fas fa-arrow-circle-left"></i> Logout</a></li>
        </ul>
    </div>
    <main>
        <div class="bookingform_container">
            <section class="main-form">
                <form id="bookkeeping-form" method="POST">
                    <h2>Business Information</h2>
                    <label for="business-name">Business Name:</label>
                    <input type="text" id="business-name" name="business-name" required>

                    <label for="business-address">Business Address:</label>
                    <input type="text" id="business-address" name="business-address" required>

                    <label for="tax-id">Tax ID:</label>
                    <input type="text" id="tax-id" name="tax-id" required>

                    <button type="submit" name="submit">Submit</button>
                </form>
            </section>
        </div>
    </main>
</body>
</html>
