<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Uni_Design_ITPROJECT.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            text-align: center;
            height: 100vh;
            display: flex;
            text-align: center;
            padding: 20px; 
            background-color: #f4f4f4; 
        }
        .login-container {
            flex-direction: column;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
            margin-left: 30px;
            height: 500px;
            width: 900px;
            margin: 0 auto; /* Centered the container */
            max-width: 900px; /* Adjusted max-width for better layout */
            height: auto;
            display: flex;
        }

        .cash-flow-container {
            display: flex;
            justify-content: space-between; /* Ensures even spacing */
            background-color: #ffffff;
            padding: 30px;
            gap: 30px;
            border-radius: 8px; /* Rounded corners for better aesthetics */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Light shadow for depth */
        }

        .cash-flow-section {
            border: 2px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            flex: 1;
            background-color: #f9f9f9; /* Light background for contrast */
        }

        label {
            display: block;
            margin-top: 10px; /* Spacing above labels */
            font-weight: bold; /* Bold labels for clarity */
        }

        input[type="text"],
        input[type="date"],
        input[type="number"] {
            width: 100%; /* Full width for inputs */
            padding: 10px; /* Padding for better touch targets */
            border: 1px solid #ccc;
            border-radius: 4px; /* Rounded corners for inputs */
            margin-top: 5px; /* Spacing between label and input */
        }

        button {
            margin-top: 15px; /* Spacing above buttons */
            padding: 10px 15px; /* Button padding */
            border: none;
            border-radius: 5px;
            background-color: #007bff; /* Primary color for buttons */
            color: white; /* Button text color */
            cursor: pointer; /* Pointer cursor for buttons */
            font-weight: bold; /* Bold button text */
        }

        button:hover {
            background-color: #0056b3; /* Darker shade on hover */
        }

        .list {
            margin-top: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            max-height: 200px;
            overflow-y: auto;
            background-color: #fff; /* White background for lists */
        }

        .footer {
            text-align: center;
            margin-top: 20px; 
        }
        .cash-flow-container {
            display: flex;
            background-color: #ffffff;
            padding: 30px;
            gap: 30px;
            width: 80%;
        }
        .cash-flow-section {
            border: 3px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            flex: 1;
        }
        .list {
            margin-top: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            max-height: 200px;
            overflow-y: auto;
        }
    </style>
    <title>Financial Report</title>
    <script src="https://kit.fontawesome.com/a05a62846d.js" crossorigin="anonymous"></script>
</head>
<body>

<?php
// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "database"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle cash inflow form submission
if (isset($_POST['add_inflow'])) {
    $source = $_POST['inflow-source'];
    $date = $_POST['inflow-date'];
    $amount = $_POST['inflow-amount'];

    $sql = "INSERT INTO inflow (source, date, amount) VALUES ('$source', '$date', $amount)";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Inflow added successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }
}

// Handle cash outflow form submission
if (isset($_POST['add_outflow'])) {
    $source = $_POST['outflow-source'];
    $date = $_POST['outflow-date'];
    $amount = $_POST['outflow-amount'];

    $sql = "INSERT INTO outflow (source, date, amount) VALUES ('$source', '$date', $amount)";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Outflow added successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }
}

// Close the connection
$conn->close();
?>

<div class="nav">
    <header>Book-Keeping</header>
    <ul>
        <li><a href="About_Page.php" aria-label="About Page"><i class="fas fa-qrcode"></i>About</a></li>
        <li><a href="applications.php" aria-label="Database"><i class="fas fa-database"></i>Business Info</a></li>
        <li><a href="ReportPage.php" aria-label="Report Page"><i class="fas fa-file"></i>Cash Inflow/ Outflow</a></li>
        <li><a href="HomePage.php" aria-label="Logout"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
    </ul>
</div>

<main>
    <div class="login-container">
        <h1>Cash Inflow/ Outflow</h1>
        <div class="cash-flow-container">
            <!-- Inflow Form -->
            <section class="cash-flow-section">
                <h3>Add Cash Inflow</h3>
                <form id="cash-inflow-form" method="POST">
                    <label for="inflow-source">Source of Inflow:</label>
                    <input type="text" id="inflow-source" name="inflow-source" required>

                    <label for="inflow-date">Date of Inflow:</label>
                    <input type="date" id="inflow-date" name="inflow-date" required>

                    <label for="inflow-amount">Amount:</label>
                    <input type="number" id="inflow-amount" name="inflow-amount" required>

                    <button type="submit" name="add_inflow">Add Inflow</button>
                </form>
                <ul id="inflow-list" class="list"></ul>
            </section>

            <!-- Outflow Form -->
            <section class="cash-flow-section">
                <h1>Add Cash Outflow</h1>
                <form id="cash-outflow-form" method="POST">
                    <label for="outflow-source">Source of Outflow:</label>
                    <input type="text" id="outflow-source" name="outflow-source" required>

                    <label for="outflow-date">Date of Outflow:</label>
                    <input type="date" id="outflow-date" name="outflow-date" required>

                    <label for="outflow-amount">Amount:</label>
                    <input type="number" id="outflow-amount" name="outflow-amount" required>

                    <button type="submit" name="add_outflow">Add Outflow</button>
                </form>
                <ul id="outflow-list" class="list"></ul>
            </section>
        </div>
    </div>
    <div class="footer">
        <footer>
            <b>IT Project: Book-Keeping System<br>Members: Cana | Lisa | Aammarah | Lolla | Erick</b>
        </footer>
    </div>
</main>

<script>
    // JavaScript for form submission, if needed
</script>
</body>
</html>
