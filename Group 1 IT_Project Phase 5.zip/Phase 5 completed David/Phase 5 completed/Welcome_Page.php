<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Uni_Design_ITPROJECT.css">
    <title>Welcome</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap');
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background-image: linear-gradient(to top right, #d4f1f4, #75e6da, #189ab4, #05445e);
            color: #004d40; 
            display: flex;
            float:none;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 0 15px;
        }

        .login-box {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            text-align: center;
            color: #004d40; 
            margin-bottom: 20px;
        }

        p {
            text-align: center;
            color: #05445e;
        }

        .nav {
            position: fixed;
            padding: 20px;
            color: #004d40;
            left: 0;
            width: 250px;
            height: 100%;
            background: #05445e;
        }

        .nav header {
            font-size: 22px;
            text-align: center;
            line-height: 70px;
            color: white;
        }

        .nav ul {
            list-style-type: none;
            padding: 0;
        }

        .nav ul a {
            display: block;
            line-height: 65px;
            font-size: 15px;
            padding-left: 20px;
            color: white;
            text-decoration: none;
            transition: padding-left 0.4s;
        }

        .nav ul a:hover {
            padding-left: 50px;
        }

        .footer {
            text-align: center;
            font-size: 15px;
            margin-top: 20px;
        }

        @media (max-width: 600px) {
            .login-box {
                padding: 20px;
            }
        }
    </style>
    <script src="https://kit.fontawesome.com/a05a62846d.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="nav">
        <header>Book-Keeping</header>
        <ul>
            <li><a href="About_Page.php" aria-label="About Page"><i class="fas fa-qrcode"></i>About</a></li>
            <li><a href="applications.php" aria-label="Database"><i class="fas fa-database"></i>Business Info</a></li>
            <li><a href="ReportPage.php" aria-label="Report Page"><i class="fas fa-file"></i>Report</a></li>
            <li><a href="HomePage.php" aria-label="Logout"><i class="fas fa-arrow-circle-left"></i>Logout</a></li>
        </ul>
    </div>

    <div class="login-box">
        <h1>Welcome to the Book-Keeping Station.</h1>
        <p>Where all your finances are managed and tracked.</p>
        <p>A chief technology officer, or CTO, is an executive who determines an organization's technology 
            strategy. As executives and strategic thinkers, CTOs rely on their knowledge of technology and 
            business acumen to guide their companies with the most up-to-date and proven solutions to improve 
            productivity and efficiency.
        </p>

        <div class="footer">
            <footer>
                <b>IT Project: Book-Keeping System<br>
                Members: Cana | Lisa | Aammarah | Lolla | Erick</b>
            </footer>
        </div>
    </div>

    <script></script>
</body>
</html>
